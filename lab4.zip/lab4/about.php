	<body>

	<?php include("header.php"); ?>	

	<div class="mainbox">
 		<div class="textbox">
 			<h3>About Us</h3>
 			<p>Information about website.</p>
 		</div>
 	</div>		
 	
 	<div class="socialmediabox">
 			<img class="socialmedialogos" src="img/facebooklogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/instagramlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/linkedinlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/twitterlogo.png" height="40"/>
 		</figure>
 	</div>	

	<?php include("footer.php"); ?>

	</body>	