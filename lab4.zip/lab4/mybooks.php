<body>	

	<?php include("header.php"); ?>		

	<div class="mainbox">
 		<div class="textbox">
 			<h3>My Books</h3>

 			<p>If you have any books reserved you will find them listed below. If empty, go to Browse Books to borrow one. Return a book by clicking the remove button.</p>

 		</div>

<?php include("config.php");

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);	


if ($db->connect_error){
	echo "Sorry, couldn't connect: this is why" . $db->connect_error; 
	exit();
}

if (isset($_GET['bookid'])){
	$bookid = $_GET['bookid'];
	$query = "UPDATE books SET is_reserved='0' where id= '$bookid'";
	$stmt = $db->prepare($query);
	$stmt->execute();
}

$query = "SELECT books.id, books.title, authors.first_name, authors.last_name, books.isbn FROM books
JOIN book_author ON books.id = book_author.book_id
JOIN authors ON authors.id = book_author.author_id
AND is_reserved=1";

$stmt = $db->prepare($query);
$stmt->bind_result($bookid, $title, $authorF, $authorL, $isbn);
$stmt->execute();


	echo "<table class='mybooks'>";
	echo "<tr><td class='head'>Book title</td><td class='head'>Name of Author</td><td class='head'>ISBN</td><td> </td></tr>";
	
while($stmt->fetch()){
	
	echo "
		<td>$title</td>
		<td>$authorF $authorL</td>
		<td>$isbn</td>
		<td><form action='' method='GET'><button class='white' name='bookid' id='".$bookid."' value='".$bookid."' type='submit'>Remove</button></form></td></tr>";
}	
	echo "</table>";	

?>			

 	</div>	

 	<div class="socialmediabox">
 			<img class="socialmedialogos" src="img/facebooklogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/instagramlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/linkedinlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/twitterlogo.png" height="40"/>
 	</div>	
 		
	<?php include("footer.php"); ?>

</body>	
