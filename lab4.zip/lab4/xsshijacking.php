<?php #include in config.php?

	#assure that cookie is only accessible via PHP (preventing attackers to access the session)

	ini_set('session.cookie_httponly', true);

	
	#lock the session to a specific user (IP), store the IP in the session and check if it matches

    if ($_SESSION['userip'] !== $_SERVER['REMOTE_ADDR']){
    
   
    #if it doesn't match, we remove all session variables -> attacker have no session
    
    session_unset();
    session_destroy();
    }

   
    #adding the html entities and string escaping on user-inputed comments 
    #allows user to enter a comment into the database, but it's encrypted

    $comment= htmlentities($comment);
	$comment= mysqli_real_escape_string($db, $comment);

?>			


	