-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 09 nov 2018 kl 11:09
-- Serverversion: 10.1.34-MariaDB
-- PHP-version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `bookclub`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `authors`
--

CREATE TABLE `authors` (
  `id` int(11) NOT NULL,
  `first_name` varchar(58) NOT NULL,
  `last_name` varchar(58) NOT NULL,
  `ssn` varchar(100) NOT NULL,
  `birth_year` datetime(6) DEFAULT NULL,
  `URL` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `authors`
--

INSERT INTO `authors` (`id`, `first_name`, `last_name`, `ssn`, `birth_year`, `URL`) VALUES
(1, 'J. K.', 'Rowling', '', NULL, ''),
(2, 'Christina', 'Knight', '', NULL, ''),
(3, 'Caroline', 'Ringskog Ferrada-Noli', '', NULL, ''),
(4, 'Paulo', 'Coelho', '', NULL, '');

-- --------------------------------------------------------

--
-- Tabellstruktur `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `pages` int(5) UNSIGNED NOT NULL,
  `isbn` varchar(100) NOT NULL,
  `publication_date` date NOT NULL,
  `edition` int(10) UNSIGNED NOT NULL,
  `publisher_id` int(11) NOT NULL,
  `is_reserved` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `books`
--

INSERT INTO `books` (`id`, `title`, `pages`, `isbn`, `publication_date`, `edition`, `publisher_id`, `is_reserved`) VALUES
(1, 'Harry Potter and the Philosopher\'s stone', 223, '0-7475-3269-9', '1997-00-00', 1, 3, 0),
(2, 'Mad Women', 183, '9789185845880', '2013-00-00', 1, 2, 0),
(3, 'Rich Boy', 476, '9789127132832', '2018-00-00', 1, 1, 0),
(4, 'The Alchemist', 163, '0-06-250217-4', '1988-00-00', 1, 4, 0);

-- --------------------------------------------------------

--
-- Tabellstruktur `book_author`
--

CREATE TABLE `book_author` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `book_author`
--

INSERT INTO `book_author` (`id`, `book_id`, `author_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4);

-- --------------------------------------------------------

--
-- Tabellstruktur `library`
--

CREATE TABLE `library` (
  `id` int(11) NOT NULL,
  `barcode` int(11) NOT NULL,
  `shelfid` int(11) NOT NULL,
  `date_included` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellstruktur `publishers`
--

CREATE TABLE `publishers` (
  `id` int(11) NOT NULL,
  `publisher` varchar(58) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `publishers`
--

INSERT INTO `publishers` (`id`, `publisher`) VALUES
(1, 'Natur Kultur'),
(2, 'Olika Förlag'),
(3, 'Bloomsbury Publishing Ltd'),
(4, 'HarperCollins');

-- --------------------------------------------------------

--
-- Tabellstruktur `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(58) NOT NULL,
  `password` varchar(58) NOT NULL,
  `first_name` varchar(58) NOT NULL,
  `last_name` varchar(58) NOT NULL,
  `email` varchar(58) NOT NULL,
  `birth_year` datetime(6) DEFAULT NULL,
  `country` varchar(58) NOT NULL,
  `usertype` varchar(58) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `email`, `birth_year`, `country`, `usertype`) VALUES
(1, 'emedb', 'abc123', 'Emelie', 'Edberg', 'emelieedberg@hotmail.com', '1989-09-10 00:00:00.000000', 'Sweden', 'browser'),
(2, 'idsan', 'ida1', 'Ida', 'Sandeberg', 'ida.sandeberg@hotmail.com', '1996-04-19 00:00:00.000000', 'Sweden', 'browser'),
(3, 'admin', 'admin1', 'Daniel', 'Wikstrom', 'daniel.wikstrom@hotmail.com', '1995-05-05 00:00:00.000000', 'Sweden', 'admin'),
(4, 'moderator', 'moderator1', 'Loredana', 'Rusu', 'loredana.rusu@hotmail.com', '1988-07-07 00:00:00.000000', 'Sweden', 'moderator');

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `book_author`
--
ALTER TABLE `book_author`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `library`
--
ALTER TABLE `library`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `publishers`
--
ALTER TABLE `publishers`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `authors`
--
ALTER TABLE `authors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT för tabell `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT för tabell `book_author`
--
ALTER TABLE `book_author`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT för tabell `library`
--
ALTER TABLE `library`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT för tabell `publishers`
--
ALTER TABLE `publishers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT för tabell `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
