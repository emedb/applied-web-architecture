	<body>
		
	<?php include("header.php"); ?>	

	<div class="mainbox-gallery">
 		<div class="textbox">
 			<h3>Gallery</h3>		

	<?php

	$files = glob("uploads/*.*");

	for ($i = 0; $i < count($files); $i++) {
	    $image = $files[$i];
	    echo '<img class="mySlides" src="'.$image .'" alt="Random image" width="100%" max height="400"/>';
	}

	?>

	<button class="slideshow" onclick="plusDivs(-1)">&#10094;</button>
	<button class="slideshow" onclick="plusDivs(+1)">&#10095;</button>

	<script>
		var slideIndex = 1;
		showDivs(slideIndex);

		function plusDivs(n) {
		  showDivs(slideIndex += n);
		}

		function showDivs(n) {
		  var i;
		  var x = document.getElementsByClassName("mySlides");
		  if (n > x.length) {slideIndex = 1}    
		  if (n < 1) {slideIndex = x.length}
		  for (i = 0; i < x.length; i++) {
		     x[i].style.display = "none";  
		  }
		  x[slideIndex-1].style.display = "block";  
		}
	</script>

 		</div>	
 	</div>	

 	<div class="socialmediabox">
 			<img class="socialmedialogos" src="img/facebooklogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/instagramlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/linkedinlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/twitterlogo.png" height="40"/>
 		</figure>
 	</div>

	<?php include("footer.php"); ?>	

	</body>	



