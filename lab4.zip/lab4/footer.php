<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link href="main.css" type="text/css" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Dancing+Script|Josefin+Sans|Lato" rel="stylesheet">
		<title>Home</title>
	</head>

	<footer>
		<p class="footer">Copyright © Emelie Edberg 2018</p>
	</footer>	

</html>