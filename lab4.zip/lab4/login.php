<?php include("config.php");

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);	


if ($db->connect_error){
	echo "Sorry, couldn't connect: this is why" . $db->connect_error; 
	exit();
}

$username = "";	 
$password = "";

if (isset($_POST) && !empty($_POST)){		 
	$username = trim($_POST['username']); 	
	$password = ($_POST['password']);
	$username = mysqli_real_escape_string($db,$username);	//sql injection code, escapes special characters in a string
	$password = mysqli_real_escape_string($db,$password);


$query = "SELECT users.username, users.password FROM users 
WHERE username ='".$username."' AND password ='".$password."'";

$stmt = $db->prepare($query);	
$stmt->bind_result($name, $pass);	
$stmt->execute();
$stmt->fetch(); //fetch values from a prepared statement 

	if ($name && $pass){
		header("Location: admin.php");
	} else {
		echo "wrong username or password";
	}
}

?>

<form action="index.php" method="POST" class="form-inline">
	<input type="text" name="username" placeholder="Enter username">	
	<input type="password" name="password" placeholder="Enter password">	
	<button class="beige" type="submit" name="submit">Log in</button>		
</form>	

	



