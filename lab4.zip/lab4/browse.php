<?php include("config.php");

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);	#open/create the db


if ($db->connect_error){
	echo "Sorry, couldn't connect: this is why" . $db->connect_error; 	#check if able to connect or not
	exit();
}

if (isset($_GET['bookid'])){		#get bookid, reserve it and update page
	$bookid = $_GET['bookid'];
	$query = "UPDATE books SET is_reserved='1' where id= '$bookid'";
	$stmt = $db->prepare($query);
	$stmt->execute();
}

$searchauthor = "";		#define var as empty 
$searchtitle = "";

if (isset($_POST) && !empty($_POST)){		#if the search-button has been clicked, and search-box not empty, then post 
	$searchauthor = trim($_POST['author']); 	#find the id 'author', take the value put inside the var 'searchauthor'
	$searchtitle = trim($_POST['title']);		#trim = take the string and trim around it, to avoid space
}

$query = "SELECT books.id, books.title, authors.first_name, authors.last_name, books.isbn FROM books
JOIN book_author ON books.id = book_author.book_id	#add data from books/authors tables to the middle table
JOIN authors ON authors.id = book_author.author_id
AND is_reserved=0"; 	#only display the books that aren't reserved


if ($searchtitle && !$searchauthor){	#if only search for title 
	$query = $query . " WHERE books.title LIKE '%" . $searchtitle . "%' "; #% = anything that comes before or after
}

if (!$searchtitle && $searchauthor){	#if only search for author
	$query = $query . " WHERE authors.first_name LIKE '%" . $searchauthor . "%' ";
}

if ($searchtitle && $searchauthor){		#if search for both
	$query = $query . " WHERE books.title LIKE '%" . $searchtitle . "%' AND authors.first_name LIKE '%" . $searchauthor . "%' ";
}

$stmt = $db->prepare($query);	#prepare sql for execusion
$stmt->bind_result($bookid, $title, $authorF, $authorL, $isbn);	#store the data somewhere
$stmt->execute();

?>	

	<body>
		
	<?php include("header.php"); ?>		

	<div class="mainbox">
 		<div class="textbox">
 			<h3>Browse Books</h3>

 			<p>Browse for books in the library by entering the name of the author or title of the book. Reserve a book by clicking the reserve button.</p>

		<form action="browse.php" method="POST" class="form-inline">
		    <input type="text" name="author" placeholder="Name of Author" class="formFields">
		    <input type="text" name="title" placeholder="Title of Book" class="formFields">
		    <button type="submit" class="beige">Search</button>
		</form>
		</div>
		
<?php include("config.php");

	echo "<table>";
	echo "<tr><td class='head'>Book title</td><td class='head'>Name of Author</td><td class='head'>ISBN</td><td> </td></tr>";
	
	while($stmt->fetch()){		#while there's something inside the statement -> echo out data

	echo "
		<td>$title</td>
		<td>$authorF $authorL</td>
		<td>$isbn</td>
		<td><form action='' method='GET'><button class='white' name='bookid' id='".$bookid."' value='".$bookid."' type='submit'>Reserve</button></form></td></tr>";
	}	
	echo "</table>";	

?>	
 	</div>	

 	<div class="socialmediabox">
 		<img class="socialmedialogos" src="img/facebooklogo.png" height="40"/>
 		<img class="socialmedialogos" src="img/instagramlogo.png" height="40"/>
 		<img class="socialmedialogos" src="img/linkedinlogo.png" height="40"/>
 		<img class="socialmedialogos" src="img/twitterlogo.png" height="40"/>
	</div>	
 		
	<?php include("footer.php"); ?>
	
	</body>	
