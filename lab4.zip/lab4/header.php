<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link href="main.css" type="text/css" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Dancing+Script|Josefin+Sans|Lato" rel="stylesheet">
		<title>Book Club</title>
	</head>
	<?php include ('config.php')?>

		<header>			
			<nav class="topnav">
				<ul> 					
	  				<li><span><a class="<?php echo ($current_page == 'index.php' || $current_page == '') ? 'active' : NULL ?>" 
	  					href="index.php">Home</a></span></li>
	  				<li><span><a class="<?php echo ($current_page == 'about.php') ? 'active' : NULL ?>" 
	  					href="about.php">About Us</a></span></li>
	 				<li><span><a class="<?php echo ($current_page == 'browse.php') ? 'active' : NULL ?>" 
	 					href="browse.php">Browse Books</a></span></li>
	 				<li><span><a class="<?php echo ($current_page == 'mybooks.php') ? 'active' : NULL ?>" 
	 					href="mybooks.php">My Books</a></span></li>
	 				<li><span><a class="<?php echo ($current_page == 'contact.php') ? 'active' : NULL ?>" 
	 					href="contact.php">Contact</a></span></li>
	 				<li><span><a class="<?php echo ($current_page == 'gallery.php') ? 'active' : NULL ?>" 
	 					href="gallery.php">Gallery</a></span></li>	 										
	 			</ul>
 			</nav>


 			<figure class="header">
 				<img src="img/bookpile.jpg"/>
 			</figure>

 			 <figure class="logo">
 				<img src="img/bookclublogo2.png"/>
 			</figure>	

		</header>		
</html>