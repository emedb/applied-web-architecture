	<body>

	<?php include("header.php"); ?>	

 		
 	<div class="mainbox">
 		<div class="textbox">
 			<h3>Welcome to the Book Club</h3>
 			<p>This is a place where you can enjoy a whole world of books 
 				with a simple click. Log in below to start reading!</p>

 		<?php include("login.php"); ?>
 				
 		</div>
 	</div>

 	<div class="socialmediabox">
 		<img class="socialmedialogos" src="img/facebooklogo.png" height="40"/>
 		<img class="socialmedialogos" src="img/instagramlogo.png" height="40"/>
 		<img class="socialmedialogos" src="img/linkedinlogo.png" height="40"/>
		<img class="socialmedialogos" src="img/twitterlogo.png" height="40"/>
 	</div>	

	<?php include("footer.php"); ?>

	</body>	