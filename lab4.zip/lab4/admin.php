<body>

<?php include("header.php"); ?>	

	<div class="mainbox">
 		<div class="textbox">
 			<h3>Admin page</h3>
 			<p>Upload an image into the gallery.</p>

<?php

if (isset($_POST['submit'])){
	$file = $_FILES['file'];

	$fileName = $_FILES['file']['name'];
	$fileTmpName = $_FILES['file']['tmp_name']; //temporary location before it's saved
	$fileSize = $_FILES['file']['size'];
	$fileError = $_FILES['file']['error'];

	$fileExt = explode('.', $fileName); //take apart string from punctuation
	$fileActualExt = strtolower(end($fileExt));	//make string lowercase
	$allowed = array('jpg', 'jpeg', 'png', 'gif'); //only quality/common pic formats
	$errors = [];	//array storing all errors


	if (!in_array($fileActualExt, $allowed)){ //if extention isn't allowed
		array_push($errors, "You cannot upload files of this type");
	}	

	if ($fileError !== 0){	//if file doesn't contain an error
		array_push($errors, "There was an error uploading your file");
	}	

	if ($fileSize > 1000000){ //if file isn't too big
		array_push($errors, "Your file is too big");
	}

	if (sizeof($errors) > 0){ //if errors array is bigger than 0, show them
		for ($i = 0; $i < sizeof($errors); $i++) { 
			echo $errors[$i];
		}
	
	} else {
		$fileDestination = 'uploads/'.$fileName; //upload to folder
		move_uploaded_file($fileTmpName, $fileDestination); //move from temp location to desired location
		echo "Upload successful";
	}
}
										//encodes the data forming the body of the request
?>		
		<form action="admin.php" method="POST" enctype="multipart/form-data"> 
			<input type="file" name="file" placeholder="insert image">	
		<button class="beige" type="submit" name="submit">Upload</button>		
		</form>	


 		</div>
 	</div>		
 	
 	<div class="socialmediabox">
 			<img class="socialmedialogos" src="img/facebooklogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/instagramlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/linkedinlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/twitterlogo.png" height="40"/>
 		</figure>
 	</div>	

<?php include("footer.php"); ?>

</body>	
	