<?php 

// $_SERVER['REQUEST_URI'])  => "localhost/lab/index.php"
$url_array = explode('/', $_SERVER['REQUEST_URI']);
$current_page = end($url_array); 


$dbserver = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'bookclub';