	<body>
		
	<?php include("header.php"); ?>	

	<div class="mainbox">
 		<div class="textbox">
 			<h3>Contact Us</h3>
 			<p>Please enter your contact info and your message.</p>
		    <form>
		      <input type="text" id="name" placeholder="Your name" class="formFields">
		      <input type="tel" id="phone" placeholder="Phone number" class="formFields">
		      <input type="text" id="email" placeholder="Email" class="formFields"><br/>
		      <input type="text" id="message" placeholder="Your message" class="formMessage"><br/>
		      <button type="submit">Send message</button>
		    </form>
 		</div>	
 	</div>	

 	<div class="socialmediabox">
 			<img class="socialmedialogos" src="img/facebooklogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/instagramlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/linkedinlogo.png" height="40"/>
 			<img class="socialmedialogos" src="img/twitterlogo.png" height="40"/>
 		</figure>
 	</div>

	<?php include("footer.php"); ?>	

	</body>	